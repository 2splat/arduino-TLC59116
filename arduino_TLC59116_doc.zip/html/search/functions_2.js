var searchData=
[
  ['best_5firef',['best_iref',['../classTLC59116__Unmanaged.html#af18ad84df715c47b8f804ca40d0f1e85',1,'TLC59116_Unmanaged']]],
  ['broadcast',['Broadcast',['../classTLC59116_1_1Broadcast.html#a9de0f10301b5d758e9204ab05d3781a1',1,'TLC59116::Broadcast::Broadcast()'],['../classTLC59116Manager.html#accc69d6286a6e8052cee7e717b54dc1f',1,'TLC59116Manager::broadcast()']]]
];
