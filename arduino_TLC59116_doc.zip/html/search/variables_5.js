var searchData=
[
  ['grpfreq_5fregister',['GRPFREQ_Register',['../classTLC59116__Unmanaged.html#a41036334e6c5d133a6603d2ce77cd615',1,'TLC59116_Unmanaged']]],
  ['grppwm_5fregister',['GRPPWM_Register',['../classTLC59116__Unmanaged.html#a3a00b3443e1b162802b6091e32f7e971',1,'TLC59116_Unmanaged']]]
];
