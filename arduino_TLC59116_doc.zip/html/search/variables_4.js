var searchData=
[
  ['eflag1_5fregister',['EFLAG1_Register',['../classTLC59116__Unmanaged.html#ad34d1083030299618a0c1efd3c36f02c',1,'TLC59116_Unmanaged']]],
  ['eflag2_5fregister',['EFLAG2_Register',['../classTLC59116__Unmanaged.html#aadfa6eaa9f44904cc26be1a78f8f9efc',1,'TLC59116_Unmanaged']]],
  ['enableoutputs',['EnableOutputs',['../classTLC59116Manager.html#ad68a6c93840f49b83f0a2eeb661c2bfe',1,'TLC59116Manager']]]
];
