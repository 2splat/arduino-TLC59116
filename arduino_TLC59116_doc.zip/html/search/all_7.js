var searchData=
[
  ['get_5fcontrol_5fregisters',['get_control_registers',['../classTLC59116__Unmanaged.html#ad961792359fc26c226ec249c19f4aeea',1,'TLC59116_Unmanaged']]],
  ['group_5fblink',['group_blink',['../classTLC59116.html#a692e0217553872561f9667aff49852c5',1,'TLC59116::group_blink(byte blink_period, byte on_ratio=128)'],['../classTLC59116.html#aee8072c3386b44ad81f629796ac129ef',1,'TLC59116::group_blink(word bit_pattern, int blink_delay, int on_ratio=128)'],['../classTLC59116.html#a7a4248ddfb1cc622684aea205aecaf7d',1,'TLC59116::group_blink(double blink_length_secs, double on_percent=50.0)'],['../classTLC59116.html#ac6af0fa0f9af8900865430be0be81672',1,'TLC59116::group_blink(word bit_pattern, double blink_length_secs, double on_percent=50.0)'],['../classTLC59116.html#a1e9644aee95d5a1209f06abe691e6fa0',1,'TLC59116::group_blink(unsigned int bit_pattern, int blink_length_secs, double on_percent=50.0)']]],
  ['group_5fpwm',['group_pwm',['../classTLC59116.html#ae7627e27217f48424fc470c46d984408',1,'TLC59116']]],
  ['grpfreq_5fregister',['GRPFREQ_Register',['../classTLC59116__Unmanaged.html#a41036334e6c5d133a6603d2ce77cd615',1,'TLC59116_Unmanaged']]],
  ['grppwm_5fregister',['GRPPWM_Register',['../classTLC59116__Unmanaged.html#a3a00b3443e1b162802b6091e32f7e971',1,'TLC59116_Unmanaged']]]
];
