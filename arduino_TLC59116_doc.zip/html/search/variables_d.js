var searchData=
[
  ['shadow_5fregisters',['shadow_registers',['../classTLC59116__Unmanaged.html#a62850581549f3f9b42cea627513a4ce9',1,'TLC59116_Unmanaged::shadow_registers()'],['../TLC59116_8h.html#af7e8b8efb01949fac25950a02c371909',1,'shadow_registers():&#160;TLC59116.h']]],
  ['subadr1',['SUBADR1',['../classTLC59116__Unmanaged.html#afad5642d19bf9e99efbb9efaf9e54ab0',1,'TLC59116_Unmanaged']]],
  ['subadr1_5fregister',['SUBADR1_Register',['../classTLC59116__Unmanaged.html#a635e42b3ba47fd94e0590a51fb5fd414',1,'TLC59116_Unmanaged']]],
  ['subadr2',['SUBADR2',['../classTLC59116__Unmanaged.html#a6b1652b6bbf3fbcec11e75a03af98b96',1,'TLC59116_Unmanaged']]],
  ['subadr3',['SUBADR3',['../classTLC59116__Unmanaged.html#a89e189b1ff1243851e10bd2a9af79d2c',1,'TLC59116_Unmanaged']]]
];
