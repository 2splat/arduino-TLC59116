var searchData=
[
  ['delay',['delay',['../classTLC59116.html#a87fc1d373025f18665fe7244922718a8',1,'TLC59116']]],
  ['describe_5factual',['describe_actual',['../classTLC59116__Unmanaged.html#afdab6558e28a80a7be27282c5f6fdad3',1,'TLC59116_Unmanaged']]],
  ['describe_5fgroup_5fmode',['describe_group_mode',['../classTLC59116__Unmanaged.html#a573db7c0d642ef90c5e1e3d62a349b1a',1,'TLC59116_Unmanaged']]],
  ['describe_5fregisters',['describe_registers',['../classTLC59116__Unmanaged.html#ac08f1bfdbd20fd8c5b4ef0f0676d1d98',1,'TLC59116_Unmanaged']]],
  ['describe_5fshadow',['describe_shadow',['../classTLC59116.html#a68f754b83544356e9194d950ecac841e',1,'TLC59116']]],
  ['device_5faddresses',['device_addresses',['../classTLC59116__Unmanaged_1_1Scan.html#ade455e5df841fbe26ee9c1008175f57a',1,'TLC59116_Unmanaged::Scan']]],
  ['device_5fcount',['device_count',['../classTLC59116Manager.html#a2eeb030f4baf9d448c5be81d5a4459aa',1,'TLC59116Manager']]]
];
