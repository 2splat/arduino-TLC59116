var searchData=
[
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]],
  ['rescan',['rescan',['../classTLC59116__Unmanaged_1_1Scan.html#aeae745741ab60a01063af34da97fd6f7',1,'TLC59116_Unmanaged::Scan']]],
  ['reset',['reset',['../classTLC59116Manager.html#a4f36fbb60b668b13d837a8f8705c8c4b',1,'TLC59116Manager::reset()'],['../classTLC59116Manager.html#a54a446ce5fc0dd75a4f88e68eb1bd334',1,'TLC59116Manager::Reset()']]],
  ['reset_5faddr',['Reset_Addr',['../classTLC59116__Unmanaged.html#a177cde2a00d1fedd5b9315c8c4d06145',1,'TLC59116_Unmanaged']]],
  ['reset_5faddress',['Reset_address',['../classTLC59116.html#a6c3cb4034fa697c86d972f262208f9d0',1,'TLC59116']]],
  ['reset_5fbytes',['Reset_Bytes',['../classTLC59116__Unmanaged.html#ad7f4f3f38a4d45e176584ef5b421ced7',1,'TLC59116_Unmanaged']]],
  ['resync_5fshadow_5fregisters',['resync_shadow_registers',['../classTLC59116.html#a404babbe19ecdbe89b3ce9d6f86032dd',1,'TLC59116']]],
  ['reverse_5fcc',['reverse_cc',['../classTLC59116__Unmanaged.html#a03d8a362da99c6785c2f3f7bfc96a167',1,'TLC59116_Unmanaged']]],
  ['rext_5fmin',['Rext_Min',['../classTLC59116__Unmanaged.html#a02efe10b964887296918703d388d762e',1,'TLC59116_Unmanaged']]]
];
