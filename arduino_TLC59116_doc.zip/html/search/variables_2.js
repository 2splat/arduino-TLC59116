var searchData=
[
  ['channels',['Channels',['../classTLC59116__Unmanaged.html#a6322264ba8447dee8794b66ea8dab12f',1,'TLC59116_Unmanaged']]],
  ['control_5fregister_5fmax',['Control_Register_Max',['../classTLC59116__Unmanaged.html#aef8378f46f17a843d232a12ee2857dd4',1,'TLC59116_Unmanaged']]],
  ['control_5fregister_5fmin',['Control_Register_Min',['../classTLC59116__Unmanaged.html#aa7dc20a12fe5e8c598fd2bdd3a6723a5',1,'TLC59116_Unmanaged']]]
];
