var searchData=
[
  ['wire',['Wire',['../TLC59116_8h.html#a35bd3de386d23ba02c35f820303db472',1,'Wire():&#160;TLC59116.h'],['../TLC59116__Unmanaged_8h.html#a35bd3de386d23ba02c35f820303db472',1,'Wire():&#160;TLC59116_Unmanaged.h']]],
  ['with_5fdelay',['with_delay',['../TLC59116_8h.html#af671bcb3cbb9d003826b86b8d99494cb',1,'TLC59116.h']]]
];
