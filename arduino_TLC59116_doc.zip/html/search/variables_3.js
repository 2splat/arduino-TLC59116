var searchData=
[
  ['default_5ffrequency',['Default_Frequency',['../classTLC59116Manager.html#a4799a8c1292d70da90c5b6c852ee66ca',1,'TLC59116Manager']]],
  ['device',['Device',['../classTLC59116__Unmanaged.html#a4e0612d4519a2b17ffc16e991d51ef3f',1,'TLC59116_Unmanaged']]]
];
