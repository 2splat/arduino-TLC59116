var searchData=
[
  ['control_5fregister',['control_register',['../classTLC59116__Unmanaged.html#a0663251c7f97864954ab540468c9949a',1,'TLC59116_Unmanaged::control_register(byte register_num)'],['../classTLC59116__Unmanaged.html#a2a09a2ec129171e92d5f742c211271e4',1,'TLC59116_Unmanaged::control_register(byte register_num, byte data)'],['../classTLC59116__Unmanaged.html#af2eb9df8ef46e153292547a2ace040e0',1,'TLC59116_Unmanaged::control_register(byte count, const byte *register_num, const byte data[])']]],
  ['count',['count',['../classTLC59116__Unmanaged_1_1Scan.html#afe1e8826af8659191d63249927f364e3',1,'TLC59116_Unmanaged::Scan']]]
];
