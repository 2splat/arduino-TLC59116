var searchData=
[
  ['i2cbus',['i2cbus',['../classTLC59116__Unmanaged.html#aaba24137ab5beb5b183158853826ea99',1,'TLC59116_Unmanaged']]],
  ['iref_5fcc_5fmask',['IREF_CC_mask',['../classTLC59116__Unmanaged.html#ad6ce5b4e6f7eb7aa884ee9846fecadf3',1,'TLC59116_Unmanaged']]],
  ['iref_5fcm_5fmask',['IREF_CM_mask',['../classTLC59116__Unmanaged.html#a1fb491782a7857c7df8a5ff29b76294e',1,'TLC59116_Unmanaged']]],
  ['iref_5fhc_5fmask',['IREF_HC_mask',['../classTLC59116__Unmanaged.html#a5957c5763bd9c38337b66b3bc592aa9a',1,'TLC59116_Unmanaged']]],
  ['iref_5fregister',['IREF_Register',['../classTLC59116__Unmanaged.html#a9ed3c3c60f6f847b4cf3e7c93860c14d',1,'TLC59116_Unmanaged']]]
];
