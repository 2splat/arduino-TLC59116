var searchData=
[
  ['_5fbegin_5ftrans',['_begin_trans',['../classTLC59116__Unmanaged.html#ab3dd16039595af68e1c79feef58ee8fd',1,'TLC59116_Unmanaged::_begin_trans(byte register_num)'],['../classTLC59116__Unmanaged.html#aed56b2a755ec2d9d2cc11199e8d4bbe4',1,'TLC59116_Unmanaged::_begin_trans(byte auto_mode, byte register_num)'],['../classTLC59116__Unmanaged.html#a5f35993516caff8f4f8327e70be8d78e',1,'TLC59116_Unmanaged::_begin_trans(TwoWire &amp;bus, byte addr, byte register_num)'],['../classTLC59116__Unmanaged.html#a1a43bde21885c9c0a83e019a34d06f87',1,'TLC59116_Unmanaged::_begin_trans(TwoWire &amp;bus, byte addr, byte auto_mode, byte register_num)']]],
  ['_5fend_5ftrans',['_end_trans',['../classTLC59116__Unmanaged.html#ac1f3a139c4f723fa09720850c5efbccf',1,'TLC59116_Unmanaged::_end_trans()'],['../classTLC59116__Unmanaged.html#aced688854f6a2eace92354dbf71647cf',1,'TLC59116_Unmanaged::_end_trans(TwoWire &amp;bus)']]]
];
